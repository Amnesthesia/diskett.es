[Database]
Host = 198.211.121.199
User = epguideuser
Password = '(DJSIODH/NC&T#/)NC#'
DbName = epguide
Charset = utf8

[Api]
Key = 5AC2A3BD00F821B8

[Mail]
Sender = EpisodeGuide
Address = noreply@epguide.com